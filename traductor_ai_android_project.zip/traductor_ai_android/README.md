# traductor.ai — proyecto Android

Incluye:
- `traductor_ai_pc.html`: versión para abrir en PC/navegador.
- Este proyecto Android: contenedor WebView para generar un APK desde Android Studio.
- Interfaz compartida en `app/src/main/assets/index.html`.

## Crear APK
1. Instala Android Studio en un computador.
2. Abre la carpeta `traductor_ai_android` como proyecto.
3. Deja que Gradle termine de sincronizar. Si pide instalar Android SDK 35, acepta.
4. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Al terminar, Android Studio muestra un enlace para localizar `app-debug.apk`.
6. Pasa el APK al teléfono Android y ábrelo para instalarlo. Es posible que Android solicite autorizar la instalación desde esa fuente.

## Conectar Gemma
La interfaz manda una solicitud `POST` a `http://HOST:PUERTO/api/solve` como `multipart/form-data` con `text`, `source`, `target` y opcionalmente `image`. El servidor debe devolver JSON, por ejemplo:
`{"result":"📘 TRADUCCIÓN ...\n📝 RESOLUCIÓN ..."}`

El frontend no incluye ni aloja Gemma automáticamente. Para que la IA responda de verdad, hay que ejecutar un servidor local compatible y usar su IP accesible. En el teléfono, `127.0.0.1` significa el propio teléfono, no el PC. Para la conexión PC-teléfono, ambos deben estar en la misma Wi-Fi y usar la IP local del PC. No publiques el servidor en internet sin protección.
